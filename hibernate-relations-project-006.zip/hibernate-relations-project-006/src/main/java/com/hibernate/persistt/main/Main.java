package com.hibernate.persistt.main;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.hibernate.persistt.entity.Address;
import com.hibernate.persistt.entity.Customer;
import com.hibernate.persistt.util.HibernateUtil;

public class Main {

	public static void main(String[] args) {
		Transaction txn = null;
		
		try(SessionFactory factory = HibernateUtil.getSessionFactory();
				Session session = factory.openSession();) {
			txn = session.beginTransaction();

            Address address =
                    new Address(
                            "Visakhapatnam",
                            "Andhra Pradesh"
                    );

            Customer customer =
                    new Customer(
                            "Ravi Kumar",
                            address
                    );
            
            session.persist(customer); // this will insert both address and customer
            //session.persist(address); // this will insert only address
			
			txn.commit();
		}
		catch(HibernateException e) {
			e.printStackTrace();
			if(txn != null)
				txn.rollback();
		}
	}

}
