package com.hibernate.refreshh.main;

public class Main {
	public static void main(String[] args) {
		
	}
}
