package com.hibernate.mergee.main;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.hibernate.mergee.entity.Address;
import com.hibernate.mergee.entity.Customer;
import com.hibernate.refreshh.util.HibernateUtil;

public class Main {

	public static void main(String[] args) {
		// STEP 1: CREATE DATA
		
		SessionFactory factory1 = null;
		Session session1 = null;
		Transaction txn1 = null;
		
		
			factory1 = new Configuration()
					.configure("hibernate.cfg.xml")
					.addAnnotatedClass(Customer.class)
					.addAnnotatedClass(Address.class)
					.buildSessionFactory();
			
			session1 = factory1.openSession();
			txn1 = session1.beginTransaction();

            Address address =
                    new Address(
                            "Visakhapatnam",
                            "Andhra Pradesh"
                    );

            Customer customer =
                    new Customer(
                            "Ravi Kumar",
                            address
                    );
            
            session1.persist(address);
            session1.persist(customer);
		
            
            //session1.merge(address);
            //session1.merge(customer);
			
            
			txn1.commit();
			
			
			factory1.close();
	
		
			
		
        // STEP 2: DETACHED OBJECT
		/*
		SessionFactory factory2 = null;
		Session session2 = null;
		
		
			factory2 = new Configuration()
					.configure("hibernate.cfg.xml")
					.addAnnotatedClass(Customer.class)
					.addAnnotatedClass(Address.class)
					.buildSessionFactory();
			session2 = factory2.openSession();
			
			
			
			Customer detachedCustomer =
	                session2.find(
	                        Customer.class,
	                        1
	                );

			factory2.close();
			
			// STEP 3: MODIFY DETACHED OBJECT
			
			detachedCustomer.setCustomerName("Ravi Kumar Reddy");
			
			detachedCustomer.getAddress().setCity("Bangalore");
			detachedCustomer.getAddress().setState("Karnataka");
			
			// STEP 4: MERGE
			
                
			SessionFactory factory3 = null;
			Session session3 = null;
			Transaction txn3 = null;
			
			
				factory3 = new Configuration()
						.configure("hibernate.cfg.xml")
						.addAnnotatedClass(Customer.class)
						.addAnnotatedClass(Address.class)
						.buildSessionFactory();
				session3 = factory3.openSession();
				txn3 = session3.beginTransaction();
				
				session3.merge(detachedCustomer); // detached entities should be merged
				//session3.persist(detachedCustomer); // detached entities can not be persisted.
				
				txn3.commit();
			
				factory3.close();
			*/
		
	}

}
