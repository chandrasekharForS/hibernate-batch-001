package com.hql.util;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.hql.entity.Address;
import com.hql.entity.Employee;
import com.hql.entity.Project;
import com.hql.entity.Skill;


public class HibernateUtil {
	private static final SessionFactory factory = buildSessionFactory();

	private static SessionFactory buildSessionFactory() {
		
		return new Configuration()
				.configure("hibernate.cfg.xml")
				.addAnnotatedClass(Employee.class)
				.addAnnotatedClass(Address.class)
				.addAnnotatedClass(Project.class)
				.addAnnotatedClass(Skill.class)
				.buildSessionFactory();
	}
	
	public static SessionFactory getSessionFactory() {
		return factory;
	}
}
