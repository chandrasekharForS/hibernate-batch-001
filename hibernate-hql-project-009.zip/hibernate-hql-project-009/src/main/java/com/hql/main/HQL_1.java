package com.hql.main;

import java.util.List;

import org.hibernate.Session;

import com.hql.entity.Employee;
import com.hql.util.HibernateUtil;

public class HQL_1 {

	public static void main(String[] args) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		
		// 1. Fetch Employees with Their Address
		
		/*String hql = "select e.name, e.salary, a.city, a.state from Employee e inner join e.address a";
		List<Object[]> result = session.createQuery(hql, Object[].class).list();
		
		for(Object[] col: result) {
			System.out.println("=========================");
			System.out.println("\nEmployee: " + col[0] + ", Salary: " + col[1] + ", City: " + col[2] + ", State: " + col[3]);
		};
		*/
		
		// 2. Fetch All Employees and Their Projects
		/*String hql = "select e.name, p.projectName from Employee as e left join e.projects as p";
		List<Object[]> result = session.createQuery(hql, Object[].class).list();
		
		for(Object[] col : result) {
			System.out.println("=========================\n");
			System.out.println("Employee: " + col[0] + ", Project: " + col[1]);
		}*/
		
		// 3. Fetch All Projects and Assigned Employees
		
		/*String hql = "select p.projectName, e.name from Project as p right join p.employees as e";
		
		List<Object[]> result = session.createQuery(hql, Object[].class).list();
		
		for(Object[] col : result) {
			System.out.println("=========================\n");
			System.out.println("Project: " + col[0] + ", Employee: " + col[1]);
		}
		*/
		
		// 4. full join
		/*String hql = "SELECT e.name, p.projectName FROM Employee e LEFT JOIN e.projects p " +
	             "UNION " +
	             "SELECT e.name, p.projectName FROM Project p RIGHT JOIN p.employees e";
		List<Object[]> result = session.createQuery(hql, Object[].class).list();
		
		for(Object[] col : result) {
			System.out.println("=========================\n");
			System.out.println("Employee : " + col[0] + ", Project: " + col[1]);
		}
		*/
		
		// 5. Fetch Number of Employees in Each Department (GROUP BY + COUNT)
		String hql = "select e.department, count(e.id)  from Employee as e group by e.department";
		List<Object[]> result = session.createQuery(hql, Object[].class).list();
		
		for(Object[] col : result) {
			System.out.println("=========================\n");
			System.out.println("Department : " + col[0] + ", Employee Count: " + col[1]);
		}
		
		session.close();;
	}
}
