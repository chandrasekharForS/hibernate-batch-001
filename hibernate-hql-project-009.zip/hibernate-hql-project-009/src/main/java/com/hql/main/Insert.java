package com.hql.main;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ThreadLocalRandom;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.github.javafaker.Faker;
import com.hql.entity.Address;
import com.hql.entity.Employee;
import com.hql.entity.Project;
import com.hql.entity.Skill;
import com.hql.util.HibernateUtil;

public class Insert {

    // ----------- TUNE THESE -----------
    private static final int SKILL_POOL   = 500;     // how many distinct skills to seed
    private static final int PROJECT_POOL = 1000;    // how many distinct projects to seed
    private static final int EMP_COUNT    = 200_000; // how many employees to insert
    private static final int CHUNK_SIZE   = 10_000;  // commit every N employees
    private static final int FLUSH_EVERY  = 1000;    // flush/clear every N employees
    // ----------------------------------

    public static void main(String[] args) {
        Faker faker = new Faker();
        ThreadLocalRandom rnd = ThreadLocalRandom.current();

        try (Session session = HibernateUtil.getSessionFactory().openSession()) {

            // 1) Seed Skills and Projects once, collect their IDs
            List<Long> skillIds = new ArrayList<>(SKILL_POOL);
            List<Long> projectIds = new ArrayList<>(PROJECT_POOL);

            Transaction seedTx = session.beginTransaction();

            for (int i = 0; i < SKILL_POOL; i++) {
                Skill s = new Skill();
                s.setSkillName(faker.job().title());
                session.persist(s);                 // IDENTITY -> insert now, ID available
                skillIds.add(s.getId());
            }

            for (int i = 0; i < PROJECT_POOL; i++) {
                Project p = new Project();
                p.setProjectName(faker.company().buzzword());
                session.persist(p);
                projectIds.add(p.getId());
            }

            seedTx.commit();
            System.out.println("Seeded " + SKILL_POOL + " skills and " + PROJECT_POOL + " projects.");

            // 2) Bulk insert employees in chunks
            int inserted = 0;
            while (inserted < EMP_COUNT) {
                int toInsertThisChunk = Math.min(CHUNK_SIZE, EMP_COUNT - inserted);
                Transaction tx = session.beginTransaction();

                for (int i = 0; i < toInsertThisChunk; i++) {
                    Employee e = new Employee();
                    e.setName(faker.name().fullName());
                    e.setSalary(rnd.nextDouble(30_000, 120_000));
                    e.setDepartment(faker.job().field()); // e.g. "Engineering", "HR"
                    e.setStatus(rnd.nextBoolean() ? "Active" : "Inactive");
                    e.setEmploymentType(rnd.nextBoolean() ? "Full-Time" : "Part-Time");
                    e.setAge(rnd.nextInt(22, 61));

                    // Address (One-to-One) — cascade persists it
                    Address a = new Address();
                    a.setStreet(faker.address().streetAddress());
                    a.setCity(faker.address().city());
                    a.setState(faker.address().state());
                    a.setZipcode(faker.address().zipCode());
                    e.setAddress(a);
                    a.setEmployee(e); // keep inverse side consistent in memory

                    // Skills (Many-to-Many) — pick 1..5 distinct from pool
                    int skillCount = rnd.nextInt(1, 6);
                    e.setSkills(pickRandomSkillRefs(session, skillIds, skillCount, rnd));

                    // Projects (Many-to-Many) — pick 1..4 distinct from pool
                    int projCount = rnd.nextInt(1, 5);
                    e.getProjects().addAll(pickRandomProjectRefs(session, projectIds, projCount, rnd));
                    // Owning side is Employee (has @JoinTable), so adding here is enough

                    session.persist(e);

                    inserted++;
                    if (inserted % FLUSH_EVERY == 0) {
                        session.flush();   // push batched inserts
                        session.clear();   // detach to free memory
                        System.out.println("Inserted " + inserted + " employees...");
                    }
                }

                tx.commit();
                System.out.println("Committed chunk. Total inserted: " + inserted + "/" + EMP_COUNT);
            }

            System.out.println("Done! Inserted " + inserted + " employees.");
        }
    }
    
    private static List<Skill> pickRandomSkillRefs(Session session, List<Long> poolIds, int count, ThreadLocalRandom rnd) {
        // ensure distinct selection
        int n = poolIds.size();
        Set<Long> picked = new HashSet<>(count * 2);
        while (picked.size() < count) {
            picked.add(poolIds.get(rnd.nextInt(n)));
        }
        List<Skill> out = new ArrayList<>(picked.size());
        for (Long id : picked) out.add(session.getReference(Skill.class, id));
        return out;
    }

    private static Set<Project> pickRandomProjectRefs(Session session, List<Long> poolIds, int count, ThreadLocalRandom rnd) {
        int n = poolIds.size();
        Set<Long> picked = new HashSet<>(count * 2);
        while (picked.size() < count) {
            picked.add(poolIds.get(rnd.nextInt(n)));
        }
        Set<Project> out = new HashSet<>(picked.size());
        for (Long id : picked) out.add(session.getReference(Project.class, id));
        return out;
    }
}
