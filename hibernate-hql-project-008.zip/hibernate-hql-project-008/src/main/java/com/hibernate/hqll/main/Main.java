package com.hibernate.hqll.main;

import java.util.List;
import java.util.Random;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.MutationQuery;

import com.github.javafaker.Faker;
import com.hibernate.hqll.entity.Employee;
import com.hibernate.hqll.util.HibernateUtil;

import jakarta.persistence.Query;

public class Main {

	public static void main(String[] args) {
		//insertEmployees();
		
		// HQL
		Session session = HibernateUtil.getSessionFactory().openSession();
		
		// 1. display all the rows
		// showAllEmployees(session);
		
		// 2.display all the employees of the department Sports
		// showAllEmployeesByDepartment(session, "Sports");
		
		// 3. update the salary of an employee
		// update employees set salary = 60000.00 where employee_id = 1;
		//updateSalary(session, 2, 75000.00);
		
		// 4. delete an employee with id 3
		// deleteEmployee(session, 5);
		
		// 5. calculate total salary
		// select sum(salary)  from employees;
		// calculateTotalSalary(session);
		
		
		
		
		session.close();
	}
	
	private static void calculateTotalSalary(Session session) {
		String hql5 = "select sum(salary) from Employee";
		double totalSalary = (double)session.createQuery(hql5, Double.class).getSingleResult();
		String totSalary = String.format("%.2f",totalSalary);
		System.out.println("Total Salary: " + totSalary);
	}
	private static void updateSalary(Session session, int newId, double newSalary) {
		String hql = """
				update Employee set salary = :newSalary 
				where id = :newId""";
		Transaction txn = session.beginTransaction();
		
		//Query query = session.createQuery(hql); //  dont give Employee.class
		
		MutationQuery query = session.createMutationQuery(hql); //  dont give Employee.class
		
		query.setParameter("newSalary", newSalary);
		query.setParameter("newId", newId);
		
		int rowsAffected = query.executeUpdate();
		txn.commit();
		
		System.out.println("The no of rows updated is " + rowsAffected);
	}
	
	private static void deleteEmployee(Session session, int newId) {
		String hql = """
				delete from Employee where id = :newId""";
		Transaction txn = session.beginTransaction();
		
		//Query query = session.createQuery(hql); //  dont give Employee.class
		
		MutationQuery query = session.createMutationQuery(hql); //  dont give Employee.class
		query.setParameter("newId", newId);
		
		int rowsAffected = query.executeUpdate();
		txn.commit();
		
		System.out.println("The row is deleted " + rowsAffected);
	}

	private static void showAllEmployees(Session session) {
		String hql1 = "from Employee";
		List<Employee> employees = session.createQuery(hql1, Employee.class).getResultList();
		
		for(Employee employee: employees) {
			System.out.println("==================");
			System.out.println(employee);
		}
	}
	
	private static void showAllEmployeesByDepartment(Session session, String department) {
		String hql1 = "from Employee e where e.department = :dept";
		Query query = session.createQuery(hql1, Employee.class);
		query.setParameter("dept", department);
		
		List<Employee> employees = query.getResultList();
		
		for(Employee employee: employees) {
			System.out.println("==================");
			System.out.println(employee);
		}
	}

	private static void insertEmployees() {
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction txn = session.beginTransaction();
		
		Faker faker = new Faker();
		Random random = new Random();
		
		int batchSize = 20;
		
		for(int i = 1; i <= 100000; i++) {
			String name = faker.name().fullName();
			double salary = 40000 + random.nextDouble() * 60000;
			String sal = String.format("%.2f", salary);
			salary = Double.parseDouble(sal);
			String department = faker.company().industry();
			
			Employee employee = new Employee(name, salary, department);
			
			session.persist(employee);
			
			if(i % batchSize == 0) {
				session.flush();
				session.clear();
			}
		}
		
		System.out.println("100000 rows inserted into the table.");
		
		txn.commit();
		session.close();
	}
}
