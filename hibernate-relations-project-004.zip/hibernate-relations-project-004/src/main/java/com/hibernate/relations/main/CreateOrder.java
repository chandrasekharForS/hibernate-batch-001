package com.hibernate.relations.main;

import java.math.BigDecimal;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.hibernate.relations.entity.Order;
import com.hibernate.relations.entity.OrderItem;
import com.hibernate.relations.util.HibernateUtil;

public class CreateOrder {

    public static void main(String[] args) {

        SessionFactory factory = HibernateUtil.getSessionFactory();
                

        Session session = factory.openSession();

        Transaction tx = session.beginTransaction();

        // Create Order
        Order order = new Order("Rajesh Kumar");

        // Create OrderItems
        OrderItem laptop = new OrderItem(
                "HP Laptop",
                1,
                new BigDecimal("72000")
        );

        OrderItem monitor = new OrderItem(
                "Dell Monitor",
                2,
                new BigDecimal("18000")
        );

        OrderItem mouse = new OrderItem(
                "Logitech Mouse",
                1,
                new BigDecimal("1200")
        );

        // Establish relationship
        order.addItem(laptop);
        order.addItem(monitor);
        order.addItem(mouse);

        // CascadeType.ALL
        // Automatically saves OrderItems
        session.persist(order);

        tx.commit();

        System.out.println(
                "Order created successfully."
        );

        System.out.println(
                "Order ID: " + order.getOrderId()
        );

        session.close();
        factory.close();
    }
}

