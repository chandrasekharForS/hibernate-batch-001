package com.hibernate.relations.main;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.hibernate.relations.entity.Order;
import com.hibernate.relations.entity.OrderItem;
import com.hibernate.relations.util.HibernateUtil;

public class ReadOrder {
    public static void main(String[] args) {
        SessionFactory factory = HibernateUtil.getSessionFactory();
                
        Session session = factory.openSession();

        Long orderId = 1L;

        Order order =
                session.find(Order.class, orderId);

        if (order != null) {

            System.out.println(
                    "Order ID: " + order.getOrderId()
            );

            System.out.println(
                    "Customer: " + order.getCustomerName()
            );

            System.out.println("Order Items:");

            for (OrderItem item : order.getItems()) {
                System.out.println(
                        "Item ID: " +
                        item.getOrderItemId()
                );

                System.out.println(
                        "Product: " +
                        item.getProductName()
                );

                System.out.println(
                        "Quantity: " +
                        item.getQuantity()
                );

                System.out.println(
                        "Price: " +
                        item.getPrice()
                );

                System.out.println("----------------------");
            }

        } else {

            System.out.println(
                    "Order not found."
            );
        }

        session.close();
        factory.close();
    }
}
