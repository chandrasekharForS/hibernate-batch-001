package com.hibernate.relations.main;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.hibernate.relations.entity.Order;
import com.hibernate.relations.entity.OrderItem;
import com.hibernate.relations.util.HibernateUtil;

public class RemoveOrderItem {
    public static void main(String[] args) {

        SessionFactory factory =
                HibernateUtil.getSessionFactory();

        Session session =
                factory.openSession();

        Transaction tx =
                session.beginTransaction();

        Long orderId = 1L;

        Order order =
                session.find(Order.class, orderId);

        if (order != null) {

            OrderItem item =
                    order.getItems().get(0);
            
            System.out.println(item);

            System.out.println(
                    "Before removing item:"
            );

            System.out.println(
                    order.getItems()
            );

            // Remove OrderItem from Order
            order.removeItem(item);
            
            tx.commit();
            
            System.out.println(
                    "After removing item:"
            );

            System.out.println(
                    order.getItems()
            );

            System.out.println(
                    "OrderItem removed successfully."
            );

        } else {

            System.out.println(
                    "Order not found."
            );

            tx.rollback();
        }

        session.close();
        factory.close();
    }
}

