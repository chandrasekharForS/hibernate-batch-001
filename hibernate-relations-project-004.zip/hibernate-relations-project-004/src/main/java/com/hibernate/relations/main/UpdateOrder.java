package com.hibernate.relations.main;

import java.math.BigDecimal;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.hibernate.relations.entity.Order;
import com.hibernate.relations.entity.OrderItem;
import com.hibernate.relations.util.HibernateUtil;

public class UpdateOrder {

    public static void main(String[] args) {

        SessionFactory factory = HibernateUtil.getSessionFactory();
        
        Session session = factory.openSession();

        Transaction tx = session.beginTransaction();

        Long orderId = 1L;

        Order order =
                session.find(Order.class, orderId);

        if (order != null) {

            // Update Order
            order.setCustomerName("Rajesh Babu");

            // Get first OrderItem
            OrderItem item =
                    order.getItems().get(0);

            // Update OrderItem
            item.setProductName("HP Pavilion Laptop");
            item.setQuantity(2);
            item.setPrice(
                    new BigDecimal("75000")
            );

            tx.commit();

            System.out.println(
                    "Order updated successfully."
            );

        } else {

            System.out.println(
                    "Order not found."
            );

            tx.rollback();
        }

        session.close();
        factory.close();
    }
}
