package com.hibernate.relations.main;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.hibernate.relations.entity.Order;
import com.hibernate.relations.util.HibernateUtil;

public class DeleteOrder {
    public static void main(String[] args) {
        SessionFactory factory = HibernateUtil.getSessionFactory();
                
        Session session = factory.openSession();

        Transaction tx = session.beginTransaction();

        Long orderId = 1L;

        Order order =
                session.find(Order.class, orderId);

        if (order != null) {

            session.remove(order);

            tx.commit();

            System.out.println(
                    "Order deleted successfully."
            );

        } else {

            System.out.println(
                    "Order not found."
            );

            tx.rollback();
        }

        session.close();
        factory.close();
    }
}

