package com.hibernate.demo;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Main {

	public static void main(String[] args) {		
		SessionFactory factory = null;
		Session session = null;
		Transaction txn = null;
		
		
		try {
			factory = HibernateUtil.getSessionFactory();
			session = factory.openSession();
			
			txn = session.beginTransaction();
			
			// 1. insert
			/*Employee emp = new Employee(103L, "Sahu", 1800000.00, "Manager");
			session.persist(emp);
			*/
			
			
			// 2. reading a row
			
			/*Employee emp = session.find(Employee.class,102);
			
			System.out.println(emp);
			*/
			
			// 3. reading all the rows
			
			// SQL (select * from employees)
			// HQL (Hibernate Query Language) (from Employee
			
			/*String hql = "FROM Employee";
			List<Employee> employees = 
					session.createQuery(hql, Employee.class).getResultList();
			
			for(Employee employee : employees)
				System.out.println(employee);
			*/
			
			/*Employee employee = session.find(Employee.class, 101);
			
			employee.setEmployeeName("Anish Kumar Ji");
			employee.setDepartment("Information Technology");
			*/
			
			Employee employee = session.find(Employee.class, 103);
			
			if(employee != null)
				session.remove(employee);
			else
				System.out.println("Employee was not present.");
			
			txn.commit();
			
		}
		catch(Exception e) {
			e.printStackTrace();
			
			if(txn != null) 
				txn.rollback();
		}
		finally {
			if(session != null)
				session.close();
			
			if(factory != null)
				factory.close();
		}

	}
}
