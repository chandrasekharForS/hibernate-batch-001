package com.hibernate.demo;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="employees")
public class Employee {
	@Id
	@Column(name = "employee_id")
	private Long employeeId;
	
	@Column(name="employee_name", unique = true)
	private String employeeName;
	
	@Column(name="salary")
	private double salary;
	
	@Column(name="department")
	private String department;
	
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Employee(Long employeeId, String employeeName, double salary, String department) {
		super();
		this.employeeId = employeeId;
		this.employeeName = employeeName;
		this.salary = salary;
		this.department = department;
	}

	public Employee(String employeeName, double salary, String department) {
		super();
		this.employeeName = employeeName;
		this.salary = salary;
		this.department = department;
	}

	public Long getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(Long employeeId) {
		this.employeeId = employeeId;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	@Override
	public String toString() {
		return "=======================" +
					"\nEmployee ID: " + employeeId +
					"\nEmployee Name: " + employeeName +
					"\nSalary: " + salary + 
					"\nDepartment: " + department;
	}
}
