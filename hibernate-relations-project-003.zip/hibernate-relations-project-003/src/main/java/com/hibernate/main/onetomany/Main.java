package com.hibernate.main.onetomany;

import java.util.Arrays;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.hibernate.entity.onetomany.Department;
import com.hibernate.entity.onetomany.Employee;
import com.hibernate.util.HibernateUtil;

public class Main {

	public static void main(String[] args) {
		Transaction txn = null;
		
		try(SessionFactory factory = HibernateUtil.getSessionFactory();
				Session session = factory.openSession();) {
			
			txn = session.beginTransaction();
			
			/*
			Department dept1 = new Department(
				    "Information Technology",
				    "Visakhapatnam"
				);

			Department dept2 = new Department(
				    "Human Resources",
				    "Bangalore"
				);
			
			Employee emp1 = new Employee(
				    "Ravi Kumar",
				    65000, dept1
				);

				Employee emp2 = new Employee(
				    "Suresh Babu",
				    72000, dept1
				);

				Employee emp3 = new Employee(
				    "Anil Sharma",
				    58000, dept1
				);

				Employee emp4 = new Employee(
				    "Priya Reddy",
				    55000, dept2
				);

				Employee emp5 = new Employee(
				    "Lakshmi Devi",
				    62000, dept2
				);
			
				//dept1.setEmployees(Arrays.asList(emp1, emp2, emp3));
				//dept2.setEmployees(Arrays.asList(emp4, emp5));
				
				
				//session.persist(emp1);
				//session.persist(emp2);
				//session.persist(emp3);
				//session.persist(emp4);
				//session.persist(emp5);
				
				
				session.persist(dept1);
				session.persist(dept2);
			
				*/
			// Select(R)
			
			/*Department department =  session.find(Department.class, 1);
			System.out.println(department);
			
			List<Employee> employees = department.getEmployees();
			
			for(Employee emp:employees)
				System.out.println(emp);
			*/
			
			/*
			Employee employee = session.find(Employee.class, 1);
			System.out.println(employee);
			
			Department department = employee.getDepartment();
			System.out.println(department);
			*/
			
			// update(U)
			
			/*
			Department department = session.find(Department.class, 1);
			
			if(department != null) {
				department.setLocation("Bangalore");
				
				List<Employee> employees = department.getEmployees();
				
				for(Employee emp: employees) {
					if(emp.getId() == 1) {
						emp.setName("Ram");
					}
				}
			}
			else {
				System.out.println("Department is not foud.");
			}
			*/
			
			// delete (D)
			/*Department department = session.find(Department.class, 2);
			if(department != null) {
				session.remove(department);
			}
			else {
				System.out.println("Department is not foud.");
			}*/
			
			/*Employee emp = session.find(Employee.class, 1);
			session.remove(emp);
			*/
			
			
			txn.commit();
		}
		catch(HibernateException e) {
			e.printStackTrace();
			if(txn != null)
				txn.rollback();
		}
		finally {
		}
		
	}

}
