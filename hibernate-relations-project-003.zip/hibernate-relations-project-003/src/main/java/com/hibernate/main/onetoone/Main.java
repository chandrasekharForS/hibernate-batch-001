package com.hibernate.main.onetoone;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.hibernate.entity.onetoone.Address;
import com.hibernate.entity.onetoone.Employee;
import com.hibernate.util.HibernateUtil;


public class Main {

	public static void main(String[] args) {
		Transaction tx  = null;
		
		
		try(SessionFactory factory =  HibernateUtil.getSessionFactory();
				Session session = factory.openSession();) {
			tx = session.beginTransaction();
			
			//1. create(c)
			// Creating Employee objects
			Employee emp1 = new Employee("Ravi Kumar", 85000.00);
			Employee emp2 = new Employee("Suresh Reddy", 95000.00);
			Employee emp3 = new Employee("Priya Sharma", 72000.00);
			Employee emp4 = new Employee("Anil Varma", 68000.00);
			Employee emp5 = new Employee("Lakshmi Devi", 78000.00);

			// Creating Address objects
			Address address1 = new Address(
			            "12-4-25", "Dwaraka Nagar",
			            "Visakhapatnam", "Andhra Pradesh", emp1
			);

			Address address2 = new Address(
			            "45-10-8", "MVP Colony",
			            "Visakhapatnam", "Andhra Pradesh", emp2
			);

			Address address3 = new Address(
			            "3-6-12", "Brodipet",
			            "Guntur", "Andhra Pradesh", emp3
			);

			Address address4 = new Address(
			            "8-2-15", "Governorpet",
			            "Vijayawada", "Andhra Pradesh", emp4
			);

			Address address5 = new Address(
			            "10-5-20", "Dargamitta",
			            "Nellore", "Andhra Pradesh", emp5
			);

			// Creating an ArrayList of Addresses
			List<Address> addresses = new ArrayList<>();

			addresses.add(address1);
			addresses.add(address2);
			addresses.add(address3);
			addresses.add(address4);
			addresses.add(address5);
			
			// Saving Employees (CascadeType.ALL will also save employees)
			for(Address address:addresses)
				session.persist(address);
		
			
			//2. read(r)
			
			/*Address address = session.find(Address.class, 1);
			
	        if (address != null) {
	        	Employee employee = address.getEmployee();
	            System.out.println("Employee Name: " + employee.getName());
	            System.out.println("Employee Salary: " + employee.getSalary());

	            System.out.println("Address: " + address.getHouseNo() + " , "+ address.getStreet() + " , " + address.getArea() + " , " + address.getState());
	        } else {
	            System.out.println("Employee not found.");
	        }
	        */
			
			
			//3. reading all the rows(r)
			/*String hql = "from Address";
			
			List<Address> addresses = session.createQuery(hql, Address.class).getResultList();
			
			for(Address address: addresses) {
				System.out.println("==================================");
				Employee employee = address.getEmployee();
	            System.out.println("Employee Name: " + employee.getName());
	            System.out.println("Employee Salary: " + employee.getSalary());

	            System.out.println("Address: " + address.getHouseNo() + " , "+ address.getStreet() + " , " + address.getArea() + " , " + address.getState());
			}
			*/
			
			// 4. update(u)
			
			/*Address address = session.find(Address.class, 1);
			
	        if (address != null) {
	        	Employee employee = address.getEmployee();
	            employee.setName("Ravi Kumar Reddy");
	            employee.setSalary(100000.00);
	            
	            address.setArea("Vizaq");
	            
	        } else {
	            System.out.println("Employee not found.");
	        }
			*/
			
			// 4. delete(d)
			/*Address address = session.find(Address.class, 2);
			
	        if (address != null) {
	        	session.remove(address);
	        } else {
	            System.out.println("Employee not found.");
	        }
	        */
			
			tx.commit();
		}
		catch(HibernateException e) {
			e.printStackTrace();
			if(tx != null)
				tx.rollback();
		}
		finally {
			
		}



	}

}
