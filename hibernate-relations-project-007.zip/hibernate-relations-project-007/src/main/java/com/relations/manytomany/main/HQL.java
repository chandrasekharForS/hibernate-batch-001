package com.relations.manytomany.main;

import java.util.List;

import org.hibernate.Session;

import com.relations.manytomany.entity.Course;
import com.relations.manytomany.entity.Student;
import com.relations.manytomany.util.HibernateUtil;

public class HQL {

	public static void main(String[] args) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		
		/*String hql1 = "from Student";
		
		List<Student> students = session.createQuery(hql1, Student.class).getResultList();
		
		for(Student student:students) {
			
			System.out.println("Student Name: " + student.getName());
			System.out.println("Courses: ");
			for(Course course:student.getCourses()) {
				System.out.println(course.getName());
			}
		}*/
		
		/*
		String hql2 = "from Course";
		List<Course> courses = session.createQuery(hql2, Course.class).getResultList();
		
		for(Course course:courses) {
			System.out.println("Course Name: " + course.getName());
			for(Student student:course.getStudents()) {
				System.out.println("Student Name: " + student.getName());
			}
			
		}
		*/
		
		// 3. Fetch students and their courses (by join)
		/*String hql3 = "select distinct s from Student s left join fetch s.courses";
		
		List<Student> students = session.createQuery(hql3, Student.class).getResultList();
		
		for(Student student:students) {
			
			System.out.println("Student Name: " + student.getName());
			System.out.println("Courses: ");
			for(Course course:student.getCourses()) {
				System.out.println(course.getName());
			}
		}*/

		
		session.close();

	}

}
