package com.relations.manytomany.util;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.relations.manytomany.entity.Course;
import com.relations.manytomany.entity.Student;

public class HibernateUtil {
	private static final SessionFactory factory = buildSessionFactory();

	private static SessionFactory buildSessionFactory() {
		
		return new Configuration()
				.configure("hibernate.cfg.xml")
				.addAnnotatedClass(Student.class)
				.addAnnotatedClass(Course.class)
				.buildSessionFactory();
	}
	
	public static SessionFactory getSessionFactory() {
		return factory;
	}
}
