package com.relations.manytomany.main;

import org.hibernate.Session;

import com.relations.manytomany.entity.Course;
import com.relations.manytomany.entity.Student;
import com.relations.manytomany.util.HibernateUtil;

public class ReadCoursesStudents {

	public static void main(String[] args) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		
		Student student = session.find(Student.class, 1);
		
		if(student != null) {
			System.out.println("Student Name: " + student.getName());
			System.out.println("Courses: ");
			for(Course course : student.getCourses()) {
				System.out.println("Course: " + course.getName());
			}
		}
		else {
			System.out.println("Student is not present.");
		}

	}

}
