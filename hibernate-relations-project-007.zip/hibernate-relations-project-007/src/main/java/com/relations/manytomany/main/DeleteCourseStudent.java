package com.relations.manytomany.main;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.relations.manytomany.entity.Student;
import com.relations.manytomany.util.HibernateUtil;

public class DeleteCourseStudent {

	public static void main(String[] args) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction txn = session.beginTransaction();
		
		Student student = session.find(Student.class, 1);
		
		if(student != null) {
			session.remove(student);
		}
		else {
			System.out.println("Student is not present.");
		}
		
		
		txn.commit();
		session.close();

	}

}
