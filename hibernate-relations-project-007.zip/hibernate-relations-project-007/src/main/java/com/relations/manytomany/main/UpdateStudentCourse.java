package com.relations.manytomany.main;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.relations.manytomany.entity.Course;
import com.relations.manytomany.entity.Student;
import com.relations.manytomany.util.HibernateUtil;

public class UpdateStudentCourse {

	public static void main(String[] args) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction txn = session.beginTransaction();
		
		Student student = session.find(Student.class, 4);
		
		if(student != null) {
			student.setName("Suresh Babu");
			
			Course course = session.find(Course.class, 2);
			student.getCourses().remove(course);
			
			Course courseToAdd = new Course("dJango");
			student.getCourses().add(courseToAdd);
			
			session.persist(courseToAdd);
			session.merge(student);
		}
		txn.commit();
		session.close();
		
		
	}

}
