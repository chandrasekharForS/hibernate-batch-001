package com.relations.manytomany.main;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;


import com.relations.manytomany.entity.Course;
import com.relations.manytomany.entity.Student;
import com.relations.manytomany.util.HibernateUtil;

public class CreateCourseStudent {

	public static void main(String[] args) {
		Transaction txn = null;
		try(
			SessionFactory factory = HibernateUtil.getSessionFactory();
			Session session = factory.openSession();) {
			txn = session.beginTransaction();
			
			Course course1 = new Course("Python");
			Course course2 = new Course("Java");
			
			Student student1 = new Student("Anish");
			Student student2 = new Student("Divya");
			Student student3 = new Student("Rajesh");
			
			Student student4 = new Student("Suresh");
			Student student5 = new Student("Vidhya");
			
			student1.enrollInCourse(course1);
			student2.enrollInCourse(course1);
			student3.enrollInCourse(course1);
			
			student1.enrollInCourse(course2);
			
			student4.enrollInCourse(course2);
			student5.enrollInCourse(course2);
			
			student4.enrollInCourse(course1);
			
			session.persist(course1);
			session.persist(course2);
			
			session.persist(student1);
			session.persist(student2);
			session.persist(student3);
			session.persist(student4);
			session.persist(student5);
			
			txn.commit();
		}
		catch(HibernateException e) {
				e.printStackTrace();
				if(txn != null)
					txn.rollback();
		}
			
	}

}
