package com.hibernate.demo;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Main {

	public static void main(String[] args) {
		Transaction tx  = null;
		
		
		try(SessionFactory factory =  HibernateUtil.getSessionFactory();
				Session session = factory.openSession();) {
			tx = session.beginTransaction();
			
			Product p1 = new Product("Mouse", 800.00, 120, "Electronics");
			
			session.persist(p1);
			
			tx.commit();
		}
		catch(HibernateException e) {
			e.printStackTrace();
			if(tx != null)
				tx.rollback();
		}
		finally {
			
		}

	}

}
